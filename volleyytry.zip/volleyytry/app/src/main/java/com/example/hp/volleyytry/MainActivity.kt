package com.example.hp.volleyytry

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.error.VolleyError
import com.android.volley.request.JsonObjectRequest
import org.json.JSONException
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    lateinit var TextView1 : TextView
    lateinit var TextView2 : TextView
    lateinit var TextView3 : TextView

    val urls = "your url"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    TextView1  = findViewById(R.id.tv1)
        TextView2 = findViewById(R.id.tv2)
        TextView3 = findViewById(R.id.tv3)

    Callapi()
    }


    private fun Callapi() {
        try {
            val request = JsonObjectRequest(Request.Method.GET, urls, null,
                    Response.Listener { response ->
                        // display response
                        Log.d("Response", response.toString())

                        try {
                            val date_response = response.getString("date")
                            val horoscope_response = response.getString("horoscope")
                            val sunsign_response = response.getString("sunsign")
                            TextView1.text = date_response

                           TextView2.text = horoscope_response

                            TextView3.text = sunsign_response
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        }

                        // Toast.makeText(context,"Response",Toast.LENGTH_LONG).show();
                    },
                    Response.ErrorListener { error ->
                        Log.d("Error.Response", error.toString())
                        //   Toast.makeText(context,"Error",Toast.LENGTH_LONG).show();
                    }
            )

            request.retryPolicy = DefaultRetryPolicy(RetryPolicy.DEFAULT,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT)
            VolleyForApplication.getInstance().addToReqQueue(request)


        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    object RetryPolicy {
        var DEFAULT = 2500000
    }


}
